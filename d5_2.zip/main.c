
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


*****************************************************************************/
// proogram to cliu
#include <stdio.h>

int main()
{
      char g;
      int yos,qual,sal;
      
      //TAKING INPUT AS GENDER  YEAR OF SERVICE  AND QUALIFICATION
      printf("Enter Gender ,Years of service  and qualification (0=G,1=PG);");
    scanf("%c%d%d",&g,&yos,&qual);
    
    //DETERMING THE SALARY ON BASED ON YEAR OF SERVICE
    if(g=='m' ||  yos>=10 && qual==1)
    {
    sal=11000;
    }
    else if((g=='m'&&yos>=10&&qual==0) || (g=='m'&&yos<10&&qual==1))
    {
        sal=10000;
    }
     else if((g=='m'&&yos<10&&qual==0)) 
    {
        sal=7000 ;
    }
    else if((g=='f'&&yos>=10&&qual==1)) 
    {
        sal=12000 ;
    }
    else if((g=='f'&&yos>=10&&qual==0))
    {
        sal=9000 ;
    }  
    else if((g=='f'&&yos<10&&qual==1)) 
   {
        sal=100000 ;
    }
     else if((g=='f'&&yos<10&&qual==0))
    {
        sal=6000;
    }
      printf("\nSalary of Employee =%d\n",sal);
    return 0;
    
}
